// This line imports the 'db' object we created in db.js.
// It allows us to use the pool.query() function to talk to our database.
// The '../' means go up one directory from 'controllers' to 'src', then find 'db.js'.
const db = require('../db');

// Function to get all todos
// This will be triggered by a GET request to /api/todos
exports.getAllTodos = async (req, res) => {
    try {
        // Use the db.query function to send a SQL query to the database
        // 'SELECT * FROM todos ORDER BY created_at DESC' gets all columns from the 'todos' table,
        // ordered by their creation date, with the newest ones first.
        const { rows } = await db.query('SELECT * FROM todos ORDER BY created_at DESC');
        // If successful, send the retrieved rows (todos) back to the client as JSON
        res.json(rows);
    } catch (err) {
        // If an error occurs, log it to the console
        console.error('Error fetching all todos:', err.message);
        // Send a 500 Internal Server Error response to the client
        res.status(500).send('Server error while fetching todos');
    }
};

// Function to add a new todo
// This will be triggered by a POST request to /api/todos
exports.addTodo = async (req, res) => {
    try {
        // Get the 'task' description from the request body
        // The frontend will send this in the JSON payload of the POST request
        const { task } = req.body;

        // Basic validation: check if the task text was provided
        if (!task || task.trim() === "") {
            return res.status(400).json({ msg: 'Task text cannot be empty' });
        }

        // SQL query to insert a new todo.
        // 'INSERT INTO todos (task) VALUES ($1) RETURNING *'
        // - (task) specifies the column to insert into.
        // - VALUES ($1) means the value for 'task' will be the first parameter we provide.
        // - RETURNING * means the database should send back all columns of the newly created todo.
        // The second argument to db.query, [task], is an array of parameters to safely insert.
        const newTodo = await db.query(
            'INSERT INTO todos (task) VALUES ($1) RETURNING *',
            [task.trim()] // Trim whitespace from the task
        );

        // Send a 201 Created status and the new todo (the first row from the result) as JSON
        res.status(201).json(newTodo.rows[0]);
    } catch (err) {
        console.error('Error adding new todo:', err.message);
        res.status(500).send('Server error while adding todo');
    }
};

// Function to update an existing todo (e.g., mark as completed, edit task text)
// This will be triggered by a PUT request to /api/todos/:id
exports.updateTodo = async (req, res) => {
    try {
        // Get the 'id' of the todo to update from the URL parameters (e.g., /api/todos/123)
        const { id } = req.params;
        // Get the 'task' description and 'is_completed' status from the request body
        const { task, is_completed } = req.body;

        // At least one field (task or is_completed) must be provided for an update
        if (task === undefined && is_completed === undefined) {
            return res.status(400).json({ msg: 'No update fields provided (task or is_completed)' });
        }
        
        // Validate task if provided
        if (task !== undefined && task.trim() === "") {
             return res.status(400).json({ msg: 'Task text cannot be empty if provided for update' });
        }

        // Validate is_completed if provided
        if (is_completed !== undefined && typeof is_completed !== 'boolean') {
            return res.status(400).json({ msg: 'is_completed must be a boolean value (true or false)' });
        }

        // Build the SQL query dynamically based on which fields are provided
        let updateQuery = 'UPDATE todos SET ';
        const queryParams = [];
        let paramIndex = 1;

        if (task !== undefined) {
            updateQuery += `task = $${paramIndex++}`;
            queryParams.push(task.trim());
        }

        if (is_completed !== undefined) {
            if (queryParams.length > 0) { // Add a comma if 'task' was also included
                updateQuery += ', ';
            }
            updateQuery += `is_completed = $${paramIndex++}`;
            queryParams.push(is_completed);
        }

        updateQuery += ` WHERE id = $${paramIndex} RETURNING *`;
        queryParams.push(id); // The id is the last parameter

        const updatedTodo = await db.query(updateQuery, queryParams);

        // Check if any row was actually updated (i.e., if the todo with that id existed)
        if (updatedTodo.rows.length === 0) {
            return res.status(404).json({ msg: 'Todo not found, nothing updated' });
        }

        // Send the updated todo back as JSON
        res.json(updatedTodo.rows[0]);
    } catch (err) {
        console.error('Error updating todo:', err.message);
        res.status(500).send('Server error while updating todo');
    }
};

// Function to delete a todo
// This will be triggered by a DELETE request to /api/todos/:id
exports.deleteTodo = async (req, res) => {
    try {
        const { id } = req.params; // Get the 'id' from the URL

        // SQL query to delete. RETURNING id (or *) helps confirm deletion.
        const deleteOp = await db.query('DELETE FROM todos WHERE id = $1 RETURNING id', [id]);

        // Check if any row was actually deleted
        if (deleteOp.rowCount === 0) {
            return res.status(404).json({ msg: 'Todo not found, nothing deleted' });
        }

        // Send a success message
        res.json({ msg: 'Todo deleted successfully', id: id });
    } catch (err) {
        console.error('Error deleting todo:', err.message);
        res.status(500).send('Server error while deleting todo');
    }
};