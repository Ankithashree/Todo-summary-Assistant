// 1. Import necessary modules
require('dotenv').config(); // Loads environment variables from .env file FIRST
                              // Make sure .env is in the root of the 'backend' folder
const express = require('express');
const cors = require('cors');

// We will import our API routes later, for example:
const todoRoutes = require('./routes/todoRoutes');

// 2. Initialize the Express application
const app = express();

// 3. Define the port
// Use the port from .env, or default to 3001 if not specified
const PORT = process.env.PORT || 3001;

// 4. Apply Middleware
// Middleware are functions that execute during the request-response cycle.

// Enable CORS (Cross-Origin Resource Sharing) for all incoming requests
// This allows your frontend (on a different port) to make requests to this backend
app.use(cors());

// Parse incoming requests with JSON payloads
// This allows your server to understand JSON data sent in request bodies (e.g., from a POST request)
app.use(express.json());

// 5. Define a Basic Test Route
// This is a simple GET route to check if the server is alive
app.get('/', (req, res) => {
    res.send('Todo Summary Assistant Backend is running!');
});

// 6. Mount API Routes
app.use('/api', todoRoutes);

// 7. Start the Server
// This makes the server listen on the specified PORT for incoming HTTP requests
app.listen(PORT, () => {
    console.log(`Backend server is listening on http://localhost:${PORT}`);
});