// This line imports the 'pg' library, which helps Node.js talk to PostgreSQL databases
const { Pool } = require('pg');

// This line helps load your secret DATABASE_URL from the .env file
// Since db.js is in 'src', and .env is one level up in 'backend', we tell it the path.
require('dotenv').config({ path: '../.env' });

// This creates a "connection pool" using your DATABASE_URL.
// A pool is an efficient way to manage database connections.
const pool = new Pool({
    connectionString: process.env.DATABASE_URL // Reads from the .env file
});

// This part is just to test if the connection works when your server starts.
pool.connect((error, client, release) => {
    if (error) {
        // If there's an error connecting, print it to the console.
        return console.error('--- ERROR: Could not connect to the database. ---', '\nDetails:', error.stack);
    }
    // If it connects, it tries to run a very simple query (SELECT NOW() gets the current time from the DB).
    client.query('SELECT NOW()', (error, result) => {
        release(); // Important: release the client connection back to the pool so others can use it.
        if (error) {
            // If the test query fails, print an error.
            return console.error('--- ERROR: Executing test query on database. ---', '\nDetails:', error.stack);
        }
        // If the query works, it prints a success message with the current time from the database.
        console.log('>>> SUCCESS: Connected to the Database! Current time from DB:', result.rows[0].now);
    });
});

// This makes a function called 'query' available to other parts of your backend.
// So, other files (like your controllers later) can use it to send SQL commands to the database.
module.exports = {
    query: (text, params) => pool.query(text, params)
};