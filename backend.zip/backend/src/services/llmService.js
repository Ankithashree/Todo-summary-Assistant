const OpenAI = require('openai');
// dotenv is already configured in server.js and db.js,
// but it's good practice if this module might be used independently or tested.
// Ensure your OPENAI_API_KEY is loaded into process.env
require('dotenv').config({ path: '../../.env' }); // Go up two levels to backend root for .env

// Check if the API key is loaded. If not, the new OpenAI() constructor will throw an error.
if (!process.env.OPENAI_API_KEY) {
    console.error("FATAL ERROR: OpenAI API key is missing. Make sure it's set in your .env file.");
    // Optionally, you could throw an error here to prevent the app from starting without it,
    // but for now, a console error will suffice. The OpenAI client will fail later anyway.
}

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Summarizes a list of todo items using the OpenAI API.
 * @param {string} todosText - A string containing the list of todo items, typically one per line.
 * @returns {Promise<string>} A promise that resolves to the summarized text.
 * @throws {Error} If the API call fails or no summary is generated.
 */
async function summarizeTodos(todosText) {
    if (!todosText || todosText.trim() === "") {
        return "No pending todos to summarize."; // Handle empty input gracefully
    }

    // Ensure the API key is available before making a call (OpenAI constructor also checks)
    if (!openai.apiKey) {
         console.error("OpenAI API key is not configured. Cannot summarize.");
         throw new Error("OpenAI API key not configured on the server for summarization.");
    }

    try {
        console.log("Sending todos to OpenAI for summarization...");
        // console.log("Todos being sent:\n", todosText); // Uncomment for debugging what's sent

        const completion = await openai.chat.completions.create({
            model: "gpt-3.5-turbo", // A good, cost-effective model for summarization
            messages: [
                {
                    role: "system",
                    content: "You are a helpful assistant that summarizes a list of to-do items. Provide a concise and actionable summary. If there are many items, try to group them or highlight the most important ones. Start the summary with a phrase like 'Here's a summary of your pending tasks:'."
                },
                {
                    role: "user",
                    content: `Please summarize these to-do items:\n${todosText}`
                }
            ],
            max_tokens: 150, // Adjust as needed. Max length of the summary.
            temperature: 0.5, // Lower for more focused, higher for more creative summaries.
        });

        const summary = completion.choices[0]?.message?.content?.trim();

        if (!summary) {
            console.error("OpenAI API returned no summary content.");
            throw new Error("Failed to generate summary: LLM returned empty content.");
        }
        
        console.log("Summary received from OpenAI.");
        return summary;

    } catch (error) {
        console.error("Error calling OpenAI API for summarization:", error.response ? error.response.data : error.message);
        // Provide a more user-friendly error or re-throw a custom error
        if (error.response && error.response.status === 401) {
            throw new Error("OpenAI API request failed: Invalid API key or authentication issue. Please check your OPENAI_API_KEY.");
        } else if (error.response && error.response.status === 429) {
            throw new Error("OpenAI API request failed: Rate limit exceeded or quota reached. Please check your OpenAI plan and usage.");
        }
        throw new Error("Failed to generate summary due to an LLM API error.");
    }
}

module.exports = { summarizeTodos };