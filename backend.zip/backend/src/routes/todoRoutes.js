const express = require('express');
const router = express.Router(); // Create an Express router instance

// Import the controller functions we created
// The '../' means go up one directory from 'routes' to 'src', then find 'controllers/todoController.js'.
const todoController = require('../controllers/todoController');
const llmSlackController = require('../controllers/llmSlackController'); // NOW USE THE ACTUAL CONTROLLER
// We will add the controller for summarization later
// const llmSlackController = require('../controllers/llmSlackController');

// Define the routes for todos:

// GET /todos - Route to get all todos
// When a GET request comes to this path, call the getAllTodos function from the controller.
router.get('/todos', todoController.getAllTodos);

// POST /todos - Route to add a new todo
// When a POST request comes to this path, call the addTodo function.
router.post('/todos', todoController.addTodo);

// PUT /todos/:id - Route to update an existing todo
// ':id' is a URL parameter that will contain the ID of the todo to update.
// When a PUT request comes to this path (e.g., /todos/1), call the updateTodo function.
router.put('/todos/:id', todoController.updateTodo);

// DELETE /todos/:id - Route to delete a todo
// When a DELETE request comes to this path (e.g., /todos/1), call the deleteTodo function.
router.delete('/todos/:id', todoController.deleteTodo);

// We will add the route for summarization later
// router.post('/summarize', llmSlackController.summarizeAndSendToSlack);
// Route to trigger summarization (and later, Slack notification)
router.post('/summarize', llmSlackController.summarizeAndNotify);

// Export the router so it can be used in server.js
module.exports = router;